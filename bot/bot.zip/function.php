<?php
function vardump($_var){
    echo '<pre>';
    var_dump($_var);
    echo '</pre>';
}