<?php
/********************************************************
 *  Function library
 *
 *  https://coderlog.top
 *  https://youtube.com/CoderLog
 ********************************************************/



/*
 Function for add users to database
*/
function add_user($connect, $username, $chat_id, $name, $old_id){
    $username = trim($username);
    $chat_id = trim($chat_id);
    $name = trim($name);

    if($chat_id == $old_id)
        return false;
    $t = "INSERT INTO users (username, chat_id, name) VALUES ('%s', '%s', '%s')";
    $query = sprintf($t, mysqli_real_escape_string($connect, $username),
        mysqli_real_escape_string($connect, $chat_id),
        mysqli_real_escape_string($connect, $name));
    $result = mysqli_query($connect, $query);
    if(!$result)
        die(mysqli_error($connect));
    return true;
}

/*
 Function for get users from database
*/

function get_user($connect, $chat_id){
    $query = sprintf("SELECT * FROM users WHERE chat_id=%d", (int)$chat_id);
    $result = mysqli_query($connect, $query);
    if(!$result)
        die(mysqli_error($connect));
    $get_user = mysqli_fetch_assoc($result);
    return $get_user;

}
//получаю все данные в виде массива
function get_all($connect){
    $query = "SELECT * FROM textlog";
    $result = mysqli_query($connect, $query);
    if(!$result)
        die(mysqli_error($connect));
    $get_user = mysqli_fetch_assoc($result);
    return $get_user;

}

/*
 Function for add text entered by user
*/

//function textlog($connect, $username, $chat_id, $name, $text){
//
//    if($chat_id == '')
//        return false;
//    $t = "INSERT INTO textlog (username, chat_id, name, text) VALUES ('%s', '%s', '%s', '%s')";
//    $query = sprintf($t, mysqli_real_escape_string($connect, $username),
//        mysqli_real_escape_string($connect, $chat_id),
//        mysqli_real_escape_string($connect, $name),
//        mysqli_real_escape_string($connect, $text));
//    $result = mysqli_query($connect, $query);
//
//    if(!$result)
//        die(mysqli_error($connect));
//    return true;
//}

function textlog2($connect, $username, $chat_id, $name, $phone, $usluga, $instagram, $old_id){
    $username = trim($username);
    $chat_id = trim($chat_id);
    $name = trim($name);

//    if($chat_id == $old_id)
//        $t = "UPDATE textlog SET username = $username, chat_id = $chat_id, name = $name, phone = $phone, usluga = $usluga, instagram = $instagram";
//    $query = sprintf($t, mysqli_real_escape_string($connect, $username),
//        mysqli_real_escape_string($connect, $chat_id),
//        mysqli_real_escape_string($connect, $name),
//        mysqli_real_escape_string($connect, $phone),
//        mysqli_real_escape_string($connect, $usluga),
//        mysqli_real_escape_string($connect, $instagram));

    if($chat_id == '')
        return false;
    $t = "INSERT INTO textlog (username, chat_id, name, phone, usluga, instagram) VALUES ('%s', '%s', '%s', '%s', '%s', '%s')";
    $query = sprintf($t, mysqli_real_escape_string($connect, $username),
        mysqli_real_escape_string($connect, $chat_id),
        mysqli_real_escape_string($connect, $name),
        mysqli_real_escape_string($connect, $phone),
        mysqli_real_escape_string($connect, $usluga),
        mysqli_real_escape_string($connect, $instagram));
    $result = mysqli_query($connect, $query);

    if(!$result)
        die(mysqli_error($connect));
    return true;
}
/*
Function to get all users from the database
*/

function users_all($connect){
    $query = "SELECT * FROM users";
    $result = mysqli_query($connect, $query);
    if(!$result)
        die(mysqli_error($connect));
    $n = mysqli_num_rows($result);
    $users_all = array();
    for ($i = 0; $i <$n; $i++){
        $row = mysqli_fetch_assoc($result);
        $users_all[] = $row;
    }
    return $users_all;
}
?>